const { useState, useEffect, useMemo, useCallback } = React;
const parseISO = (str) => new Date(str);
const startOfDay = (d) => { const nd = new Date(d); nd.setHours(0,0,0,0); return nd; };
const startOfMonth = (d) => { const nd = new Date(d); nd.setDate(1); nd.setHours(0,0,0,0); return nd; };
const endOfMonth = (d) => { const nd = new Date(d); nd.setMonth(nd.getMonth() + 1); nd.setDate(0); nd.setHours(23,59,59,999); return nd; };
const addDays = (d, days) => { const nd = new Date(d); nd.setDate(nd.getDate() + days); return nd; };
const isSameDay = (d1, d2) => d1.getDate() === d2.getDate() && d1.getMonth() === d2.getMonth() && d1.getFullYear() === d2.getFullYear();
const differenceInDays = (d1, d2) => Math.floor((d1.getTime() - d2.getTime()) / (1000 * 3600 * 24));
const isWithinInterval = (d, { start, end }) => d.getTime() >= start.getTime() && d.getTime() <= end.getTime();
const eachDayOfInterval = ({ start, end }) => {
  const days = [];
  let current = startOfDay(start);
  const last = startOfDay(end);
  while (current <= last) {
    days.push(current);
    current = addDays(current, 1);
  }
  return days;
};
const format = (date, fmt) => {
  const d = new Date(date);
  const DD = String(d.getDate()).padStart(2, '0');
  const MM = String(d.getMonth() + 1).padStart(2, '0');
  const YYYY = d.getFullYear();
  const HH = String(d.getHours()).padStart(2, '0');
  const mm = String(d.getMinutes()).padStart(2, '0');
  const EEE = ['Нд', 'Пн', 'Вт', 'Ср', 'Чт', 'Пт', 'Сб'][d.getDay()];
  const MMMM = ['Січень', 'Лютий', 'Березень', 'Квітень', 'Травень', 'Червень', 'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'][d.getMonth()];
  const MMM = ['Січ', 'Лют', 'Бер', 'Кві', 'Тра', 'Чер', 'Лип', 'Сер', 'Вер', 'Жов', 'Лис', 'Гру'][d.getMonth()];
  
  if (fmt === 'yyyy-MM-dd') return `${YYYY}-${MM}-${DD}`;
  if (fmt === 'dd.MM.yyyy') return `${DD}.${MM}.${YYYY}`;
  if (fmt === 'dd.MM.yyyy HH:mm') return `${DD}.${MM}.${YYYY} ${HH}:${mm}`;
  if (fmt === 'dd.MM') return `${DD}.${MM}`;
  if (fmt === 'dd MMM') return `${DD} ${MMM}`;
  if (fmt === 'dd MMM, yyyy') return `${DD} ${MMM}, ${YYYY}`;
  if (fmt === 'dd') return `${DD}`;
  if (fmt === 'E') return EEE;
  if (fmt === 'MMMM yyyy') return `${MMMM} ${YYYY}`;
  if (fmt === 'MMM yyyy') return `${MMM} ${YYYY}`;
  return d.toISOString();
};

// --- Icons ---
function IconMenu() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="4" x2="20" y1="12" y2="12"/><line x1="4" x2="20" y1="6" y2="6"/><line x1="4" x2="20" y1="18" y2="18"/></svg>; }
function IconCalendar() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect width="18" height="18" x="3" y="4" rx="2" ry="2"/><line x1="16" x2="16" y1="2" y2="6"/><line x1="8" x2="8" y1="2" y2="6"/><line x1="3" x2="21" y1="10" y2="10"/></svg>; }
function IconDoor() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 22v-4a2 2 0 1 0-4 0v4"/><path d="m18 22 3-3"/><path d="M8 14H6"/><path d="M18 13v-4c0-2.8-2.2-5-5-5H6c-2.8 0-5 2.2-5 5v13"/><path d="M22 13v-4c0-2.8-2.2-5-5-5h-6"/></svg>; }
function IconSettings() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12.22 2h-.44a2 2 0 0 0-2 2v.18a2 2 0 0 1-1 1.73l-.43.25a2 2 0 0 1-2 0l-.15-.08a2 2 0 0 0-2.73.73l-.22.38a2 2 0 0 0 .73 2.73l.15.1a2 2 0 0 1 1 1.72v.51a2 2 0 0 1-1 1.74l-.15.09a2 2 0 0 0-.73 2.73l.22.38a2 2 0 0 0 2.73.73l.15-.08a2 2 0 0 1 2 0l.43.25a2 2 0 0 1 1 1.73V20a2 2 0 0 0 2 2h.44a2 2 0 0 0 2-2v-.18a2 2 0 0 1 1-1.73l.43-.25a2 2 0 0 1 2 0l.15.08a2 2 0 0 0 2.73-.73l.22-.39a2 2 0 0 0-.73-2.73l-.15-.08a2 2 0 0 1-1-1.74v-.5a2 2 0 0 1 1-1.74l.15-.09a2 2 0 0 0 .73-2.73l-.22-.38a2 2 0 0 0-2.73-.73l-.15.08a2 2 0 0 1-2 0l-.43-.25a2 2 0 0 1-1-1.73V4a2 2 0 0 0-2-2z"/><circle cx="12" cy="12" r="3"/></svg>; }
function IconPlus() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="12" x2="12" y1="5" y2="19"/><line x1="5" x2="19" y1="12" y2="12"/></svg>; }
function IconX() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" x2="6" y1="6" y2="18"/><line x1="6" x2="18" y1="6" y2="18"/></svg>; }
function IconChevronLeft() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m15 18-6-6 6-6"/></svg>; }
function IconChevronRight() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="m9 18 6-6-6-6"/></svg>; }
function IconSave() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z"/><polyline points="17 21 17 13 7 13 7 21"/><polyline points="7 3 7 8 15 8"/></svg>; }
function IconSearch() { return <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.3-4.3"/></svg>; }
function IconBell() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 8a6 6 0 0 1 12 0c0 7 3 9 3 9H3s3-2 3-9"/><path d="M10.3 21a1.94 1.94 0 0 0 3.4 0"/></svg>; }
function IconSun() { return <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2"/><path d="M12 20v2"/><path d="m4.93 4.93 1.41 1.41"/><path d="m17.66 17.66 1.41 1.41"/><path d="M2 12h2"/><path d="M20 12h2"/><path d="m6.34 17.66-1.41 1.41"/><path d="m19.07 4.93-1.41 1.41"/></svg>; }
function IconArrivals() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 20h20"/><path d="m5 16 3-3 3 3"/><path d="M8 16V3"/><path d="m18 16 3-3-3-3"/></svg>; }
function IconDepartures() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M2 20h20"/><path d="m5 10 3 3 3-3"/><path d="M8 3v10"/><path d="m18 10 3 3-3 3"/></svg>; }
function IconInHouse() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M3 9.5 12 4l9 5.5"/><path d="M19 13v6.4a.6.6 0 0 1-.6.6H5.6a.6.6 0 0 1-.6-.6V13"/></svg>; }
function IconTools() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a2 2 0 0 1-2.83-2.83l-3.94 3.6Z"/><path d="m10 14 3 3"/><path d="m9 15-4.5 4.5a2.12 2.12 0 1 1-3-3L6 12"/><path d="M15 5 5 15"/></svg>; }
function IconUsers() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M22 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>; }
function IconReports() { return <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"/><line x1="12" y1="20" x2="12" y2="4"/><line x1="6" y1="20" x2="6" y2="14"/></svg>; }

// --- Constants & Init Data ---
const BREAKFAST_OPTIONS = ['Омлет', 'Яєчня', 'Сирники', 'Вівсянка', 'Млинці', 'Сендвіч'];
const SOURCES = ['Телефон', 'Booking.com', 'Airbnb', 'Сайт', 'Інше'];

const getInitialRooms = () => Array.from({length: 12}, (_, i) => ({
  id: String(i + 1),
  number: String(i + 1),
  type: i < 4 ? 'Стандарт' : i < 8 ? 'Комфорт' : 'Люкс',
  capacity: i < 4 ? 2 : i < 8 ? 3 : 4,
  price: i < 4 ? 3000 : i < 8 ? 5000 : 8000,
  description: 'Затишний номер з прекрасним видом.'
}));

// --- State Management ---
function useAppState() {
  const [rooms, setRooms] = useState(() => {
    const saved = localStorage.getItem('hotel_rooms');
    return saved ? JSON.parse(saved) : getInitialRooms();
  });
  
  const [bookings, setBookings] = useState(() => {
    const saved = localStorage.getItem('hotel_bookings');
    const parsed = saved ? JSON.parse(saved) : [];
    if (parsed.length > 0) return parsed;
    
    // Default mock bookings for demo
    const today = startOfDay(new Date());
    return [
      {
        id: '1',
        roomId: '1',
        guestName: 'Сара Дженкінс',
        phone: '+1 234 567 8901',
        guestsCount: 2,
        checkIn: format(today, 'yyyy-MM-dd'),
        checkOut: format(addDays(today, 3), 'yyyy-MM-dd'),
        source: 'Booking.com',
        status: 'occupied',
        isPaid: true
      },
      {
        id: '2',
        roomId: '2',
        guestName: 'Маркус Торн',
        phone: '+1 987 654 3210',
        guestsCount: 1,
        checkIn: format(addDays(today, 1), 'yyyy-MM-dd'),
        checkOut: format(addDays(today, 2), 'yyyy-MM-dd'),
        source: 'Телефон',
        status: 'checkout',
        isPaid: false
      }
    ];
  });

  const [webhookUrl, setWebhookUrl] = useState(() => {
    return localStorage.getItem('hotel_webhook') || '';
  });

  useEffect(() => {
    localStorage.setItem('hotel_rooms', JSON.stringify(rooms));
  }, [rooms]);

  useEffect(() => {
    localStorage.setItem('hotel_bookings', JSON.stringify(bookings));
  }, [bookings]);

  useEffect(() => {
    localStorage.setItem('hotel_webhook', webhookUrl);
  }, [webhookUrl]);

  const sendToSheets = async (bookingData, isNew) => {
    if (!webhookUrl) return;
    try {
      const payload = {
        action: isNew ? 'CREATE' : 'UPDATE',
        timestamp: new Date().toISOString(),
        ...bookingData
      };
      
      // In a real scenario we use fetch, but to avoid CORS in no-cors mode, we might just try
      await fetch(webhookUrl, {
        method: 'POST',
        mode: 'no-cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(payload)
      });
      console.log('Sent to Google Sheets');
    } catch (e) {
      console.error('Failed to send to Google Sheets', e);
    }
  };

  const addBooking = (booking) => {
    const newBooking = { ...booking, id: uuid.v4(), createdAt: new Date().toISOString() };
    setBookings(prev => [...prev, newBooking]);
    sendToSheets(newBooking, true);
  };

  const updateBooking = (booking) => {
    setBookings(prev => prev.map(b => b.id === booking.id ? booking : b));
    sendToSheets(booking, false);
  };

  const deleteBooking = (id) => {
    setBookings(prev => prev.filter(b => b.id !== id));
  };

  const updateRoom = (room) => {
    setRooms(prev => prev.map(r => r.id === room.id ? room : r));
  };

  return { rooms, bookings, addBooking, updateBooking, deleteBooking, updateRoom, webhookUrl, setWebhookUrl };
}

// --- Components ---

function Toast({ message, type }) {
  if (!message) return null;
  return (
    <div className="toast-container">
      <div className={`toast ${type}`}>
        <span>{message}</span>
      </div>
    </div>
  );
}

function Sidebar({ currentView, setCurrentView, onNewBooking, occupancy }) {
  return (
    <aside className="sidebar">
      <div className="sidebar-header">
        <div className="logo-container">
          <div className="logo-icon">
            <IconInHouse />
          </div>
          <div className="logo-text">
            <span className="logo-main">Grand Stay</span>
            <span className="logo-sub">12 ROOMS HOTEL</span>
          </div>
        </div>
      </div>

      <nav className="sidebar-nav">
        <a className={`nav-item ${currentView === 'calendar' ? 'active' : ''}`} onClick={() => setCurrentView('calendar')}>
          <IconCalendar /> Календар
        </a>
        <a className={`nav-item ${currentView === 'rooms' ? 'active' : ''}`} onClick={() => setCurrentView('rooms')}>
          <IconDoor /> Номери
        </a>
        <a className={`nav-item ${currentView === 'list' ? 'active' : ''}`} onClick={() => setCurrentView('list')}>
          <IconUsers /> Гості
        </a>
        <a className={`nav-item ${currentView === 'reports' ? 'active' : ''}`} onClick={() => setCurrentView('reports')}>
          <IconReports /> Звіти
        </a>
        <a className={`nav-item ${currentView === 'settings' ? 'active' : ''}`} onClick={() => setCurrentView('settings')}>
          <IconSettings /> Налаштування
        </a>
      </nav>

      <div className="sidebar-user">
        <img src="https://ui-avatars.com/api/?name=Oleg+Petrov&background=3b82f6&color=fff" alt="User" className="user-avatar" />
        <div className="user-info">
          <div className="user-name">Олег Петров</div>
          <div className="user-role">Старший менеджер</div>
        </div>
        <IconSettings size={14} style={{ color: 'var(--text-tertiary)', cursor: 'pointer' }} />
      </div>

      <div className="sidebar-footer">
        <button className="btn btn-primary" style={{ width: '100%', padding: '16px' }} onClick={onNewBooking}>
          <IconPlus /> Нове бронювання
        </button>
      </div>
    </aside>
  );
}

function TopBar() {
  return null; // TopBar is now integrated into Sidebar
}

function StatCards({ arrivals, departures, inHouse, maintenance }) {
  return (
    <div className="stats-row">
      <div className="stat-card">
        <div className="stat-icon"><IconArrivals /></div>
        <div className="stat-content">
          <span className="stat-label">Прибуття</span>
          <span className="stat-value">{arrivals}</span>
        </div>
      </div>
      <div className="stat-card">
        <div className="stat-icon"><IconDepartures /></div>
        <div className="stat-content">
          <span className="stat-label">Від'їзди</span>
          <span className="stat-value">{departures}</span>
        </div>
      </div>
      <div className="stat-card">
        <div className="stat-icon"><IconInHouse /></div>
        <div className="stat-content">
          <span className="stat-label">Проживання</span>
          <span className="stat-value">{inHouse}</span>
        </div>
      </div>
      <div className="stat-card">
        <div className="stat-icon" style={{ color: '#FACC15' }}><IconTools /></div>
        <div className="stat-content">
          <span className="stat-label">Ремонт</span>
          <span className="stat-value">{maintenance}</span>
        </div>
      </div>
    </div>
  );
}

function SettingsView({ webhookUrl, setWebhookUrl, showToast }) {
  const [url, setUrl] = useState(webhookUrl);

  const handleSave = () => {
    setWebhookUrl(url);
    showToast('Налаштування збережено', 'success');
  };

  return (
    <div className="content-area" style={{ padding: '40px' }}>
      <h2 style={{ marginBottom: '24px' }}>Налаштування Webhook</h2>
      <div className="card" style={{ padding: '32px' }}>
        <p style={{ color: 'var(--text-secondary)', marginBottom: '16px', fontSize: '14px' }}>
          Вставте URL вашого Google Apps Script Webhook. При кожному створенні або зміні бронювання дані будуть відправлятися на цю адресу.
        </p>
        <div className="form-group">
          <label className="form-label">Webhook URL</label>
          <input 
            type="text" 
            className="form-control" 
            value={url} 
            onChange={(e) => setUrl(e.target.value)} 
            placeholder="https://script.google.com/macros/s/.../exec"
          />
        </div>
        <button className="btn btn-primary" onClick={handleSave} style={{ marginTop: '20px' }}>
          <IconSave /> Зберегти
        </button>
      </div>
    </div>
  );
}

function RoomsView({ rooms, updateRoom, showToast }) {
  const [editingRoom, setEditingRoom] = useState(null);

  const handleSave = (e) => {
    e.preventDefault();
    updateRoom(editingRoom);
    setEditingRoom(null);
    showToast('Номер успішно оновлено', 'success');
  };

  return (
    <div className="content-area" style={{ padding: '40px' }}>
      <h2 style={{ marginBottom: '24px' }}>Налаштування номерів</h2>
      <div className="rooms-grid" style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: '20px' }}>
        {rooms.map(room => (
          <div key={room.id} className="card" style={{ padding: '24px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '16px' }}>
              <h3 style={{ margin: 0 }}>Номер {room.number}</h3>
              <span className="room-card-type">{room.type}</span>
            </div>
            <div className="room-card-detail"><span>Тип:</span> {room.type}</div>
            <div className="room-card-detail"><span>Місткість:</span> {room.capacity} чол.</div>
            <div className="room-card-detail"><span>Ціна:</span> {room.price} грн/ніч</div>
            <button className="btn btn-secondary" style={{ width: '100%', marginTop: '16px' }} onClick={() => setEditingRoom({...room})}>
              Редагувати
            </button>
          </div>
        ))}
      </div>

      {editingRoom && (
        <div className="modal-overlay">
          <div className="modal-content" style={{ maxWidth: '500px' }}>
            <div className="modal-header">
              <h3>Редагування номера {editingRoom.number}</h3>
              <button className="icon-btn" onClick={() => setEditingRoom(null)}><IconX /></button>
            </div>
            <form onSubmit={handleSave} style={{ padding: '24px' }}>
              <div className="form-group">
                <label className="form-label">Ціна (грн/ніч)</label>
                <input type="number" className="form-control" value={editingRoom.price} onChange={e => setEditingRoom({...editingRoom, price: parseInt(e.target.value)})} />
              </div>
              <div className="form-group">
                <label className="form-label">Тип номера</label>
                <input type="text" className="form-control" value={editingRoom.type} onChange={e => setEditingRoom({...editingRoom, type: e.target.value})} />
              </div>
              <div style={{ display: 'flex', gap: '12px', marginTop: '24px', justifyContent: 'flex-end' }}>
                <button type="button" className="btn btn-secondary" onClick={() => setEditingRoom(null)}>Скасувати</button>
                <button type="submit" className="btn btn-primary">Зберегти</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

function BookingModal({ isOpen, onClose, onSave, onDelete, initialData, rooms }) {
  const [formData, setFormData] = useState({
    roomId: '',
    guestName: '',
    phone: '',
    guestsCount: 1,
    checkIn: format(new Date(), 'yyyy-MM-dd'),
    checkOut: format(addDays(new Date(), 1), 'yyyy-MM-dd'),
    source: 'Телефон',
    paymentType: 'Готівка',
    isPaid: false,
    earlyCheckIn: false,
    lateCheckOut: false,
    parking: false,
    breakfast: 'Без сніданку',
    comments: '',
    status: 'occupied',
    ...initialData
  });

  useEffect(() => {
    if (initialData) {
      setFormData({ ...formData, ...initialData });
    }
  }, [initialData]);

  if (!isOpen) return null;

  const handleChange = (field, value) => {
    setFormData(prev => ({ ...prev, [field]: value }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    onSave(formData);
  };

  const isEditing = !!formData.id;

  return (
    <div className="modal-overlay">
      <div className="modal-card">
        <div className="modal-header">
          <div className="modal-title-group">
            <span className="modal-subtitle">ПАНЕЛЬ УПРАВЛІННЯ > {isEditing ? 'РЕДАГУВАТИ БРОНЮВАННЯ' : 'НОВЕ БРОНЮВАННЯ'}</span>
            <h2 className="modal-main-title">{isEditing ? 'Редагувати бронь' : 'Створити бронювання'}</h2>
          </div>
          <button className="icon-btn" onClick={onClose}><IconX /></button>
        </div>
        <form onSubmit={handleSubmit} className="modal-body">
          <div className="left-panel">
            <div className="modal-section">
              <div className="section-header">
                <IconUsers size={18} /> Дані гостя та перебування
              </div>
              <div className="form-row">
                <div className="input-group">
                  <label className="label">Повне ім'я</label>
                  <input type="text" className="field" placeholder="напр. Іван Іванов" value={formData.guestName} onChange={e => handleChange('guestName', e.target.value)} required />
                </div>
                <div className="input-group">
                  <label className="label">Номер телефону</label>
                  <input type="tel" className="field" placeholder="+38 (000) 000-0000" value={formData.phone} onChange={e => handleChange('phone', e.target.value)} required />
                </div>
              </div>
              <div className="form-row">
                <div className="input-group">
                  <label className="label">Дата заїзду</label>
                  <input type="date" className="field" value={formData.checkIn} onChange={e => handleChange('checkIn', e.target.value)} required />
                </div>
                <div className="input-group">
                  <label className="label">Дата виїзду</label>
                  <input type="date" className="field" value={formData.checkOut} onChange={e => handleChange('checkOut', e.target.value)} required />
                </div>
              </div>
              <div className="form-row">
                <div className="input-group">
                  <label className="label">Кількість гостей</label>
                  <input type="number" className="field" value={formData.guestsCount} onChange={e => handleChange('guestsCount', parseInt(e.target.value))} min="1" />
                </div>
                <div className="input-group">
                  <label className="label">Вибір номера</label>
                  <select className="field" value={formData.roomId} onChange={e => handleChange('roomId', e.target.value)} required>
                    <option value="" disabled>Оберіть номер</option>
                    {rooms.map(r => <option key={r.id} value={r.id}>Номер {r.number} - {r.type}</option>)}
                  </select>
                </div>
              </div>
            </div>

            <div className="modal-section">
              <div className="section-header">
                <IconTools size={18} /> Послуги та харчування
              </div>
              <div className="form-row">
                <div className="input-group">
                  <label className="label">Додаткові послуги</label>
                  <div className="checkbox-group" style={{ display: 'flex', flexDirection: 'column', gap: '10px', marginTop: '8px' }}>
                    <label className="checkbox-label">
                      <input type="checkbox" className="checkbox-input" checked={formData.parking} onChange={e => handleChange('parking', e.target.checked)} /> Паркомісце
                    </label>
                    <label className="checkbox-label">
                      <input type="checkbox" className="checkbox-input" checked={formData.earlyCheckIn} onChange={e => handleChange('earlyCheckIn', e.target.checked)} /> Ранній заїзд (10:00)
                    </label>
                    <label className="checkbox-label">
                      <input type="checkbox" className="checkbox-input" checked={formData.lateCheckOut} onChange={e => handleChange('lateCheckOut', e.target.checked)} /> Пізній виїзд (16:00)
                    </label>
                  </div>
                </div>
                <div className="input-group">
                  <label className="label">Варіант сніданку</label>
                  <select className="field" value={formData.breakfast} onChange={e => handleChange('breakfast', e.target.value)}>
                    <option value="Без сніданку">Без сніданку</option>
                    <option value="Стандартний">Стандартний сніданок</option>
                    <option value="Преміум">Преміум сніданок</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="modal-section">
              <div className="section-header">
                <IconReports size={18} /> Коментарі до замовлення
              </div>
              <textarea className="field" style={{ minHeight: '100px' }} placeholder="Додайте особливі побажання, нотатки про алергії або деталі прибуття..." value={formData.comments} onChange={e => handleChange('comments', e.target.value)}></textarea>
            </div>
          </div>

          <div className="right-panel">
            <div className="panel-card">
              <div className="section-header" style={{ border: 'none', padding: 0, marginBottom: '20px' }}>
                 Оплата та джерело
              </div>
              <div className="input-group" style={{ marginBottom: '20px' }}>
                <label className="label">Джерело бронювання</label>
                <select className="field" value={formData.source} onChange={e => handleChange('source', e.target.value)}>
                  {['Booking.com', 'Airbnb', 'Телефон', 'Сайт'].map(s => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <label className="label" style={{ marginBottom: '12px', display: 'block' }}>Тип оплати</label>
              <div className="radio-group">
                {['Готівка', 'Кредитна картка', 'Банківський переказ'].map(type => (
                  <div key={type} className={`radio-item ${formData.paymentType === type ? 'active' : ''}`} onClick={() => handleChange('paymentType', type)}>
                    <span>{type}</span>
                    <div style={{ width: '16px', height: '16px', borderRadius: '50%', border: '2px solid', borderColor: formData.paymentType === type ? 'var(--accent-color)' : '#333', display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
                       {formData.paymentType === type && <div style={{ width: '8px', height: '8px', borderRadius: '50%', background: 'var(--accent-color)' }}></div>}
                    </div>
                  </div>
                ))}
              </div>
              
              <div className="billing-list" style={{ marginTop: '30px' }}>
                 <div className="billing-total">
                    <span>СТАТУС</span>
                    <span style={{ color: 'var(--accent-color)' }}>{formData.isPaid ? 'ОПЛАЧЕНО' : 'НЕ ОПЛАЧЕНО'}</span>
                 </div>
              </div>
            </div>

            <div className="action-buttons">
               <button type="submit" className="btn btn-primary"><IconSave /> Зберегти бронювання</button>
               <button type="button" className="btn btn-dark" onClick={onClose}><IconX /> Скасувати</button>
               {isEditing && <button type="button" className="btn btn-danger" onClick={() => { if(confirm('Видалити бронювання?')) onDelete(formData.id); }}><IconPlus size={16} style={{ transform: 'rotate(45deg)' }} /> Видалити бронь</button>}
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}

function BookingsTableView({ rooms, bookings, onOpenModal }) {
  const getRoomNumber = (id) => rooms.find(r => r.id === id)?.number || '?';

  return (
    <div className="content-area" style={{ padding: '40px' }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '24px', alignItems: 'center' }}>
        <h2 style={{ margin: 0 }}>Усі бронювання</h2>
        <button className="btn btn-primary" onClick={() => onOpenModal({})}>
          <IconPlus /> Нове бронювання
        </button>
      </div>
      <div className="card" style={{ overflow: 'hidden' }}>
        <table className="bookings-table" style={{ width: '100%', borderCollapse: 'collapse' }}>
          <thead>
            <tr>
              <th>Номер</th>
              <th>Гість</th>
              <th>Заїзд</th>
              <th>Виїзд</th>
              <th>Джерело</th>
              <th>Оплата</th>
              <th>Дії</th>
            </tr>
          </thead>
          <tbody>
            {bookings.sort((a, b) => new Date(b.checkIn) - new Date(a.checkIn)).map(booking => (
              <tr key={booking.id}>
                <td><div className="room-number-badge">№ {getRoomNumber(booking.roomId)}</div></td>
                <td>
                  <div style={{ fontWeight: 600 }}>{booking.guestName}</div>
                  <div style={{ fontSize: '12px', color: 'var(--text-secondary)' }}>{booking.phone}</div>
                </td>
                <td>{format(parseISO(booking.checkIn), 'dd.MM.yyyy')}</td>
                <td>{format(parseISO(booking.checkOut), 'dd.MM.yyyy')}</td>
                <td><span className="source-tag">{booking.source}</span></td>
                <td>{booking.isPaid ? <span style={{ color: 'var(--status-free-text)' }}>Оплачено</span> : <span style={{ color: 'var(--danger-color)' }}>Не оплачено</span>}</td>
                <td>
                  <button className="btn btn-secondary" style={{ padding: '6px 12px', fontSize: '12px' }} onClick={() => onOpenModal(booking)}>
                    Деталі
                  </button>
                </td>
              </tr>
            ))}
            {bookings.length === 0 && (
              <tr>
                <td colSpan="7" style={{ textAlign: 'center', padding: '40px', color: 'var(--text-secondary)' }}>
                  Бронювань поки немає
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}

function CalendarView({ rooms, bookings, onOpenModal }) {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [viewMode, setViewMode] = useState('month'); 

  const daysInView = useMemo(() => {
    if (viewMode === 'month') {
      const start = startOfMonth(currentDate);
      const end = endOfMonth(currentDate);
      return eachDayOfInterval({ start, end });
    } else {
      const start = startOfDay(currentDate);
      const end = addDays(start, 6);
      return eachDayOfInterval({ start, end });
    }
  }, [currentDate, viewMode]);

  const prevPeriod = () => setCurrentDate(prev => addDays(prev, viewMode === 'month' ? -30 : -7));
  const nextPeriod = () => setCurrentDate(prev => addDays(prev, viewMode === 'month' ? 30 : 7));
  
  const getBookingsForRoom = (roomId) => {
    return bookings.filter(b => b.roomId === roomId).map(b => {
      const checkIn = parseISO(b.checkIn);
      const checkOut = parseISO(b.checkOut);
      return { ...b, checkIn, checkOut };
    });
  };

  const today = startOfDay(new Date());
  const arrivals = bookings.filter(b => isSameDay(parseISO(b.checkIn), today)).length;
  const departures = bookings.filter(b => isSameDay(parseISO(b.checkOut), today)).length;
  const inHouse = bookings.filter(b => {
    const cin = parseISO(b.checkIn);
    const cout = parseISO(b.checkOut);
    return cin <= today && cout > today;
  }).length;

  return (
    <div className="content-wrapper" style={{ paddingTop: '0' }}>
      <div className="page-header" style={{ marginBottom: '4px' }}>
        <div style={{ display: 'flex', gap: '8px', alignItems: 'center' }}>
          <h2 style={{ fontSize: '14px', fontWeight: 600, color: 'var(--text-secondary)' }}>
            {format(daysInView[0], 'dd MMM').toUpperCase()} — {format(daysInView[daysInView.length - 1], 'dd MMM, yyyy').toUpperCase()}
          </h2>
           <div className="view-switcher">
              <button className={`view-btn ${viewMode === 'week' ? 'active' : ''}`} onClick={() => setViewMode('week')}>ТИЖДЕНЬ</button>
              <button className={`view-btn ${viewMode === 'month' ? 'active' : ''}`} onClick={() => setViewMode('month')}>МІСЯЦЬ</button>
           </div>
           <div style={{ display: 'flex', alignItems: 'center', gap: '12px', background: 'var(--bg-surface)', padding: '6px 16px', borderRadius: 'var(--radius-md)', border: '1px solid var(--border-color)' }}>
              <button className="icon-btn" style={{ padding: '4px' }} onClick={prevPeriod}><IconChevronLeft /></button>
              <span style={{ fontSize: '12px', fontWeight: 700, minWidth: '150px', textAlign: 'center' }}>
                {format(daysInView[0], 'dd MMM').toUpperCase()} — {format(daysInView[daysInView.length - 1], 'dd MMM, yyyy').toUpperCase()}
              </span>
              <button className="icon-btn" style={{ padding: '4px' }} onClick={nextPeriod}><IconChevronRight /></button>
           </div>
        </div>
      </div>

      <div className="calendar-card">
        <div className="calendar-top">
          <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
             <span style={{ fontSize: '11px', fontWeight: 700, color: 'var(--text-tertiary)', textTransform: 'uppercase' }}>Каталог номерів</span>
             <IconMenu size={14} style={{ color: 'var(--text-tertiary)' }} />
          </div>
          <div className="calendar-legend">
            <div className="legend-item"><span className="legend-dot" style={{ background: 'var(--status-occupied)' }}></span> Зайнято</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: 'var(--status-checkout)' }}></span> Виїзд сьогодні</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: 'var(--status-early)' }}></span> Ранній заїзд</div>
            <div className="legend-item"><span className="legend-dot" style={{ background: 'var(--status-cleaning)' }}></span> Прибирання</div>
          </div>
        </div>

        <div className={`calendar-scroll-box ${viewMode === 'month' ? 'scroll-x' : ''}`}>
          <div className="calendar-grid" style={viewMode === 'week' ? { width: '100%' } : {}}>
            <div className="calendar-row" style={{ display: 'grid', gridTemplateColumns: viewMode === 'week' ? `200px repeat(${daysInView.length}, 1fr)` : `200px repeat(${daysInView.length}, 100px)`, position: 'relative' }}>
              <div className="grid-header-cell room-sidebar-cell" style={{ borderBottom: '1px solid var(--border-color)' }}></div>
              {daysInView.map((day, i) => (
                <div key={i} className="grid-header-cell">
                  <div className="header-day-name">{format(day, 'E')}</div>
                  <div className={`header-day-num ${isSameDay(day, today) ? 'active' : ''}`}>{format(day, 'dd')}</div>
                </div>
              ))}
            </div>

            {rooms.map(room => {
              const roomBookings = getBookingsForRoom(room.id);
              const isWeek = viewMode === 'week';
              const colTemplate = isWeek
                ? `200px repeat(${daysInView.length}, 1fr)`
                : `200px repeat(${daysInView.length}, 100px)`;

              return (
                <div key={room.id} className="calendar-row" style={{ display: 'grid', gridTemplateColumns: colTemplate, position: 'relative' }}>
                  {/* Room label — always col 1, row 1 */}
                  <div className="room-sidebar-cell" style={{ gridColumn: 1, gridRow: 1 }}>
                    <span className="room-number-label">НОМЕР {room.number}</span>
                  </div>

                  {/* Day cells — cols 2..N, row 1 */}
                  {daysInView.map((day, i) => (
                    <div
                      key={i}
                      className="grid-cell"
                      style={{ gridColumn: i + 2, gridRow: 1 }}
                      onClick={() => onOpenModal({ roomId: room.id, checkIn: format(day, 'yyyy-MM-dd') })}
                    />
                  ))}

                  {/* Booking capsules */}
                  {roomBookings.map(booking => {
                    const startIdx = daysInView.findIndex(d => isSameDay(d, booking.checkIn));
                    const endIdx = daysInView.findIndex(d => isSameDay(d, booking.checkOut));
                    if (startIdx === -1 && endIdx === -1) return null;

                    const totalCols = daysInView.length;
                    let statusClass = 'occupied';
                    if (booking.status === 'checkout') statusClass = 'checkout';
                    if (booking.status === 'early') statusClass = 'early';
                    const paidLabel = booking.isPaid ? 'ОПЛАЧЕНО' : 'НЕ ОПЛАЧЕНО';
                    const statusLabel = booking.status === 'occupied' ? 'ЗАЙНЯТО' : booking.status === 'checkout' ? 'ВИЇЗД' : 'РАННІЙ ЗАЇЗД';

                    if (isWeek) {
                      // Week mode: use grid-column to span the booking within the same grid
                      const colStart = (startIdx === -1 ? 0 : startIdx) + 2;
                      const colEnd = (endIdx === -1 ? totalCols : endIdx) + 2;
                      const span = Math.max(1, colEnd - colStart);
                      return (
                        <div
                          key={booking.id}
                          className={`booking-capsule week-capsule ${statusClass}`}
                          style={{ gridColumn: `${colStart} / span ${span}`, gridRow: 1 }}
                          onClick={(e) => { e.stopPropagation(); onOpenModal(booking); }}
                        >
                          <span className="capsule-name">{booking.guestName}</span>
                          <span className="capsule-info">{statusLabel} • {paidLabel}</span>
                        </div>
                      );
                    }

                    // Month mode: absolute pixel positioning with fixed 100px columns
                    const cellPx = 100;
                    const sidebarPx = 200;
                    const s = startIdx === -1 ? sidebarPx : startIdx * cellPx + sidebarPx + cellPx / 2;
                    const e = endIdx === -1 ? totalCols * cellPx + sidebarPx : endIdx * cellPx + sidebarPx + cellPx / 2;
                    const leftPx = Math.max(sidebarPx, s);
                    const widthPx = Math.max(0, e - leftPx);

                    return (
                      <div
                        key={booking.id}
                        className={`booking-capsule ${statusClass}`}
                        style={{ left: `${leftPx}px`, width: `${widthPx}px` }}
                        onClick={(e) => { e.stopPropagation(); onOpenModal(booking); }}
                      >
                        <span className="capsule-name">{booking.guestName}</span>
                        <span className="capsule-info">{statusLabel} • {paidLabel}</span>
                      </div>
                    );
                  })}
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}


function App() {
  const { rooms, bookings, addBooking, updateBooking, deleteBooking, updateRoom, webhookUrl, setWebhookUrl } = useAppState();
  const [currentView, setCurrentView] = useState('calendar');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingBooking, setEditingBooking] = useState(null);
  
  const [toastMessage, setToastMessage] = useState(null);
  const [toastType, setToastType] = useState('success');

  const showToast = (message, type = 'success') => {
    setToastMessage(message);
    setToastType(type);
    setTimeout(() => setToastMessage(null), 3000);
  };

  const handleOpenModal = (bookingData = {}) => {
    setEditingBooking(bookingData);
    setModalOpen(true);
  };

  const handleSaveBooking = (data) => {
    if (data.id) {
      updateBooking(data);
      showToast('Бронювання оновлено');
    } else {
      addBooking(data);
      showToast('Бронювання створено');
    }
    setModalOpen(false);
  };

  const handleDeleteBooking = (id) => {
    deleteBooking(id);
    showToast('Бронювання видалено');
    setModalOpen(false);
  };

  // Today's occupancy
  const today = startOfDay(new Date());
  const occupiedTodayCount = bookings.filter(b => {
    const cin = parseISO(b.checkIn);
    const cout = parseISO(b.checkOut);
    return cin <= today && cout > today;
  }).length;
  const occupancy = rooms.length ? Math.round((occupiedTodayCount / rooms.length) * 100) : 0;

  return (
    <div className="app-container">
      <Sidebar 
        currentView={currentView} 
        setCurrentView={setCurrentView} 
        onNewBooking={() => handleOpenModal({})} 
        occupancy={occupancy}
      />
      
      <main className="main-content">
        {currentView === 'calendar' && <CalendarView rooms={rooms} bookings={bookings} onOpenModal={handleOpenModal} />}
        {currentView === 'list' && <BookingsTableView rooms={rooms} bookings={bookings} onOpenModal={handleOpenModal} />}
        {currentView === 'rooms' && <RoomsView rooms={rooms} updateRoom={updateRoom} showToast={showToast} />}
        {currentView === 'settings' && <SettingsView webhookUrl={webhookUrl} setWebhookUrl={setWebhookUrl} showToast={showToast} />}
      </main>

      <BookingModal 
        isOpen={modalOpen} 
        onClose={() => setModalOpen(false)} 
        onSave={handleSaveBooking} 
        onDelete={handleDeleteBooking}
        initialData={editingBooking}
        rooms={rooms}
      />

      <Toast message={toastMessage} type={toastType} />
    </div>
  );
}

class ErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { hasError: false, error: null };
  }

  static getDerivedStateFromError(error) {
    return { hasError: true, error };
  }

  render() {
    if (this.state.hasError) {
      return (
        <div style={{ padding: '40px', color: 'red', fontFamily: 'sans-serif' }}>
          <h2>Something went wrong in React.</h2>
          <pre>{this.state.error.toString()}</pre>
        </div>
      );
    }
    return this.props.children; 
  }
}

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(<ErrorBoundary><App /></ErrorBoundary>);
